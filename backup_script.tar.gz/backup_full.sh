#!/bin/bash
origen=$1
destino=$2

echo "Empezando backup..."

if [ ! -d $origen ]; then
    echo "Error: $origen no existe"
    exit 1
fi

mkdir -p $destino

fecha=`date +%Y%m%d`
nombre=`basename $origen`
archivo=$nombre"_bkp_"$fecha".tar.gz"

echo "Creando: $archivo"

tar -czf $destino/$archivo -C `dirname $origen` `basename $origen`

echo "Listo!"
